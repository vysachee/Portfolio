package View;

import java.awt.FlowLayout;
import java.awt.event.MouseListener;
import javax.swing.JButton;
import javax.swing.JPanel;

public class South extends JPanel{
    
    JButton stop;
    JButton start;  //button to start the game (also shuffle)
    JButton reset;
    
    public South(MouseListener ml) {
        super();
        this.setLayout(new FlowLayout());
        this.setBackground(new java.awt.Color(0,102, 0));
        //inizialize buttons (STOP & START)
        stop = new JButton("STOP");
        start = new JButton("START");
        reset = new JButton("RESET");
        
        //adding MouseListener
        stop.addMouseListener(ml);
        start.addMouseListener(ml);
        reset.addMouseListener(ml);
        
        //set the turn for the player
        stop.setActionCommand("PLAYER");
        
        this.add(stop); 
        this.add(start);
        //this.add(reset);
    }
    
    //getter for the button stop
    public JButton getStop() {
        return stop;
    }
    
    //getter for the button start
    public JButton getStart() {
        return start;
    }

    public JButton getReset() {
        return reset;
    }
    

}
