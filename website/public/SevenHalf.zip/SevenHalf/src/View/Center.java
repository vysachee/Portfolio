package View;

import java.awt.Color;
import java.awt.GridLayout;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Center extends JPanel{
    
    
    JLabel player1,player2,p1Score,p2Score;
    
    public Center() {
        super();
        this.setBackground(new java.awt.Color(0,102, 0));
        this.setLayout(new GridLayout(0,1));
        
        ImageIcon img = new ImageIcon("carte/CartaRosso.jpg");
        player1 = new JLabel("",JLabel.CENTER);
        player2 = new JLabel("",JLabel.CENTER);
        p1Score = new JLabel("PLAYER SCORE: ",JLabel.CENTER);
        p2Score = new JLabel("BANK SCORE: ",JLabel.CENTER);
        
        p1Score.setForeground(Color.WHITE);
        p2Score.setForeground(Color.WHITE);
        
        
        player1.setIcon(img);
        player2.setIcon(img);
        
        player1.setEnabled(false);
        player2.setEnabled(false);
        
        this.add(player2);
        this.add(p2Score);
        this.add(p1Score);
        this.add(player1);
        
    }

    public JLabel getPlayer1() {
        return player1;
    }

    public JLabel getPlayer2() {
        return player2;
    }

    public JLabel getP1Score() {
        return p1Score;
    }

    public JLabel getP2Score() {
        return p2Score;
    }   
}
