package View;

import Control.Engine;
import Model.FullDeck;
import Model.Hand;
import java.awt.BorderLayout;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class Frame extends JFrame implements MouseListener{
    
    //player and bank hand
    Hand playerHand = new Hand();
    Hand bankHand = new Hand();
    
    //full deck
    FullDeck fd = new FullDeck();
    
    East east;
    Center center;
    South south;
    
    public Frame() {
        super("Seven Half");
        
        //setting size, layout and position of the window
        this.setSize(800,575);
        this.getContentPane().setBackground(new java.awt.Color(0,102, 0));
        this.setLayout(new BorderLayout());
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        //initialize and adding panels into the window
        east = new East(this);
        center = new Center();
        south = new South(this);

        this.add(east,BorderLayout.EAST);
        this.add(center,BorderLayout.CENTER);
        this.add(south,BorderLayout.SOUTH);
        this.add(new JLabel("                        "), BorderLayout.WEST);
        east.getDeck().setEnabled(false);
        south.getStop().setEnabled(false);
        east.getDeck().setActionCommand("BANK");
        
    }
    
    @Override
    public void mouseClicked(MouseEvent e) {
        
        //START
        if(e.getComponent() == south.getStart()){
            //shuffle the deck and start the game
            Engine.start(fd,east.getDeck(),south.getStop(),south.getStart(), center.getPlayer1(),center.getPlayer2(),playerHand, center.getPlayer1(),center.getP1Score());
        }
        
        //ADD CARD
        if(e.getComponent() == east.getDeck() && "PLAYER".equals(east.getDeck().getActionCommand())){
            //pick a card
            Engine.pick(fd, playerHand, bankHand, center.getPlayer1(), center.getPlayer2(), center.getP1Score(),center.getP2Score(),south.getStop(),east.getDeck());
        }
        
        //stop and 
        if(e.getComponent() == south.getStop()){
            //shuffle the deck and start the game
            Engine.stop(south.getStop(), east.getDeck());
            Engine.pick(fd, playerHand, bankHand, center.getPlayer1(), center.getPlayer2(), center.getP1Score(),center.getP2Score(),south.getStop(),east.getDeck());
        }
        
        /*if(e.getComponent() == south.getReset()){
            Engine.reset(fd, playerHand, bankHand,center.getPlayer1(), center.getPlayer2(), center.getP1Score(),center.getP2Score(),south.getStop(),east.getDeck(), south.getStart());
        }*/
    }

    @Override
    public void mousePressed(MouseEvent e) {
    }

    @Override
    public void mouseReleased(MouseEvent e) {
    }

    @Override
    public void mouseEntered(MouseEvent e) {
    }

    @Override
    public void mouseExited(MouseEvent e) {
    }
}
