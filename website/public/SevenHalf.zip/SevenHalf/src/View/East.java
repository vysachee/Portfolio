package View;

import java.awt.GridLayout;
import java.awt.event.MouseListener;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JPanel;

public class East extends JPanel{
    
    JButton deck;    //deck label
    ImageIcon deckImg;  //image of the deck
    
    public East(MouseListener ml) {
        //set layout
        this.setLayout(new GridLayout(0,1));
        this.setBackground(new java.awt.Color(0,102, 0));
        
        //inizialize the elements
        deck = new JButton();
        deck.setBorder(BorderFactory.createEmptyBorder());
        deck.setContentAreaFilled(false);
        
        deckImg = new ImageIcon("carte/CartaRosso.jpg");
        
        //setting the image
        deck.setIcon(deckImg);
        
        //adding MouseListener for the deck
        deck.addMouseListener(ml);

        //adding the elements in the panel
        this.add(deck);
        
    }
    
    //getter for the deck
    public JButton getDeck() {
        return deck;
    }
    
} 
