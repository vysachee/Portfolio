package sevenhalf;

import View.Frame;

public class SevenHalf {

    public static void main(String[] args) {
        Frame win = new Frame();
        win.setVisible(true);
    }
    
}
