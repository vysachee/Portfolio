package Model;

import java.util.Random;

public class FullDeck extends Hand{
    private float point;
    
    int i;
    public FullDeck() {
         super();
        
        for(i = 1; i <=10; i++){
            if(i>=8){
                point = (float) 0.5;
            }else{
                point = i;
            }
            this.add(new Card(i,"c",point));
        }
        for(i = 1; i <=10; i++){
            if(i>=8){
                point = (float) 0.5;
            }else{
                point = i;
            }
            this.add(new Card(i,"q",point));
        }
        for(i = 1; i <=10; i++){
            if(i>=8){
                point = (float) 0.5;
            }else{
                point = i;
            }
            this.add(new Card(i,"f",point));
        }
        for(i = 1; i <=10; i++){
            if(i>=8){
                point = (float) 0.5;
            }else{
                point = i;
            }
            this.add(new Card(i,"p",point));
        }
    }
    
    //method for the deck
    public void shuffle(){       
        Random rnd = new Random();
        Card dummy;
        int num;
        for(i = 1; i < 40; i++){
            num = rnd.nextInt(this.size());
            dummy = this.get(i);
            this.set(i,this.get(num));
            this.set(num, dummy);     
        }   
    }  
    
    //method for pick a card
    public Card popCard(){
        Card c;
        c = this.remove(0);
        return c;
    }
    
}
