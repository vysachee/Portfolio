package Model;

import java.util.ArrayList;
import javax.swing.ImageIcon;
import javax.swing.JLabel;

public class Hand extends ArrayList<Card>{
    
    public Hand() {
       super(); 
    }
    
    public ImageIcon update(Card card, JLabel label){
        ImageIcon img;
        
        img = new ImageIcon("carte/" + card.toString() + ".jpg");
        label.setIcon(img);
       
        return img;
    }
    
     //method for calculating the score 
    public float calc(){
        float tot = 0;
        for(int i = 0; i<this.size();i++){
            tot = tot + this.get(i).getPoint();           
        }
        return tot;
    }
}
