package Model;

public class Card {
    private final String seed;
    private final int value;
    private final float point;
    public Card(int value, String seed, float point) {
        this.seed = seed;
        this.value = value;
        this.point = point;
    }

    @Override
    public String toString() {
      String out;
      String valueS = "";
      if(value < 8){
        out = value + seed;  
      }else{
        if(value == 8){
            valueS = "j"; 
        } 
        if(value == 9){
            valueS = "q"; 
         } 
        if(value == 10){
            valueS = "k"; 
        } 
        out = valueS + seed;
      }
      
      return out;
    }
    
    public float getPoint() {
        return point;
    }

    public String getSeed() {
        return seed;
    }

    public int getValue() {
        return value;
    }
    
}
