package Control;

import Model.Card;
import Model.FullDeck;
import Model.Hand;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;

public class Engine {
    
    public static void start(FullDeck fullDeck,  JButton deck, JButton stop, JButton start, JLabel player1, JLabel player2, Hand playerHand, JLabel playerLabel, JLabel playerScore){
        //System.out.println("You clicked 'deck'");
        Card card;
        
        fullDeck.shuffle();
        deck.setEnabled(true);
        stop.setEnabled(true);
        player1.setEnabled(true);
        player2.setEnabled(true);
        start.setEnabled(false);
        
        card = fullDeck.popCard();
        playerHand.add(card);
        playerHand.update(card, playerLabel);
        playerScore.setText("PLAYER SCORE: " + playerHand.calc());
        deck.setActionCommand("PLAYER");
    }
    
    public static void stop(JButton stop, JButton deck){
        stop.setActionCommand("BANK");
        deck.setActionCommand("BANK");
        deck.setEnabled(false);
    }
    
    /*public static void reset(FullDeck fullDeck, Hand playerHand, Hand bankHand, JLabel playerLabel, JLabel bankLabel, JLabel playerScore, JLabel bankScore, JButton stop, JButton deck, JButton start){
        fullDeck = new FullDeck();
        playerHand = new Hand();
        bankHand = new Hand();
        
        ImageIcon img = new ImageIcon("carte/CartaRosso.jpg");
        
        playerLabel.setIcon(img);
        bankLabel.setIcon(img);
        
        playerScore.setText("PLAYER SCORE: ");
        bankScore.setText("BANK SCORE: ");
        
        start.setEnabled(true);
        deck.setEnabled(false);
        stop.setEnabled(false);
        
        deck.setActionCommand("BANK");
    }*/
    
    public static void pick(FullDeck fullDeck, Hand playerHand, Hand bankHand, JLabel playerLabel, JLabel bankLabel, JLabel playerScore, JLabel bankScore, JButton stop, JButton deck){

        Card card;
        //pick the card from the deck
        card = fullDeck.popCard();
        
        if(stop.getActionCommand() == "PLAYER"){

            //add the card to the hand
            playerHand.add(card);

            //update the window
            playerHand.update(card, playerLabel);

            //if stoned
            if(playerHand.calc() > 7.5){
                playerScore.setText("STONED || " + playerHand.calc());
                deck.setEnabled(false);
                deck.setActionCommand("BANK");
            }else{
                //calculate total and display it
                playerScore.setText("PLAYER SCORE: " + playerHand.calc());
            }
        
        }else{
            
            while(bankHand.calc() < 6.5){

                bankHand.add(card);

                bankHand.update(card,bankLabel); 

                if(bankHand.calc() > 7.5){
                    bankScore.setText("STONED || " + bankHand.calc());
                }else{
                    //calculate total and display it
                    bankScore.setText("BANK SCORE: " + bankHand.calc()+"");
                }
            }
                  
            if(playerHand.calc() > bankHand.calc() && playerHand.calc() < 7.5 || bankHand.calc() > 7.5 && playerHand.calc() < 7.5 || bankHand.calc() > 7.5 && playerHand.calc() > 7.5 && playerHand.calc() < bankHand.calc()){
                playerScore.setText("PLAYER WINS || " + playerHand.calc()); 
                bankScore.setText("BANK LOSES || " + bankHand.calc());
            }else{
                playerScore.setText("PLAYER LOSES || " + playerHand.calc()); 
                bankScore.setText("BANK WINS || " + bankHand.calc());
            }                       

            //TIE
            if(playerHand.calc() == bankHand.calc()){
                playerScore.setText("TIE || " + playerHand.calc());
                bankScore.setText("TIE || " + bankHand.calc()); 
            }
            
            stop.setEnabled(false);
        }   
    }  
}